#!/usr/bin/env python3


def reverse(lst: list, idx: int) -> None:
    for i in range(idx):
        if i > idx:
            print(f'List state: {lst}')
            return
        lst[idx], lst[i] = lst[i], lst[idx]
        idx -= 1
    print(f'List state: {lst}')


def max(lst: list, idx1: int, idx2: int) -> int:
    return idx1 if lst[idx1] > lst[idx2] else idx2


def reverse_sort(lst: list) -> None:
    for i in range(len(lst) - 1, 0, -1):
        min_value = i
        for j in range(0, i):
            if max(lst, j, min_value) == min_value:
                min_value = j
        if i == min_value:
            continue
        reverse(lst, min_value)
        reverse(lst, i)
    print(f'Sorted List: {lst}')


def is_reverse_sorted(lst: list) -> bool:
    for i in range(len(lst) - 1):
        if lst[i] < lst[i + 1]:
            return False
    return True


def main() -> int:
    nb_list = [16, 17, 18, 19, 20, 1, 2, 3, 4, 5, 15, 14, 13, 12, 11, 10, 6, 7, 8, 9]
    reverse_sort(nb_list)


if __name__ == "__main__":
    exit(main())
